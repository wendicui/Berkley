package BallingBoards;

import  java.util.*;

public class Test {
    Test(){
    }

    public static void main (String[] args){
        Data ballingData = new Data();
        //add games
        Date date = new GregorianCalendar(2014, Calendar.FEBRUARY, 11).getTime();
        Date date2 = new GregorianCalendar(2015, Calendar.FEBRUARY, 11).getTime();
        //Player John
        ballingData.input("John", 34,date);
        ballingData.input("John", 61,date2);
        //Player Doe
        ballingData.input("Doe", 32,date);
        ballingData.input("Doe", 94,date2);

        ballingData.printData();
    }



}
