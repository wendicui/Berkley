package Printline;

public class ToolargeNumber  extends Exception {
    public ToolargeNumber() {
        System.out.println("There are not that many lines in the data");
    };
}
